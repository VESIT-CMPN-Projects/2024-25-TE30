import { AuthScreen } from "@/features/auth/components/auth-screen";

const AuthPage = () =>{
    return(
        <AuthScreen />
    )
}

export default AuthPage;